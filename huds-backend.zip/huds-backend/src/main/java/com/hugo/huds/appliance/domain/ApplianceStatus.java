package com.hugo.huds.appliance.domain;

public class ApplianceStatus {
}
