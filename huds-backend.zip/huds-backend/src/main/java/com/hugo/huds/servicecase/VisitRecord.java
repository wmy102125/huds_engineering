package com.hugo.huds.servicecase;

public class VisitRecord {
}
